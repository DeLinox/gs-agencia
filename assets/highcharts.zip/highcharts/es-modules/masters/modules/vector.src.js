/**
 * @license  @product.name@ JS v@product.version@ (@product.date@)
 * Vector plot series module
 *
 * (c) 2010-2017 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/vector.src.js';
